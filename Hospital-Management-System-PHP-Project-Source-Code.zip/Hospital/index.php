<?php
include("header.php");
?>
<div class="wrapper col1" style="background-color: gray">
  <center>
  <div id="container">
    <div id="content">
      <img src="images/hospital.png" alt="..." width="150%">
      <center>
      <div class="homecontent">
        <ul>
          <li>
            <h2 style="background-color: gray;color: white">Book your Appointment through online</h2>
            <p class="imgholder" style="background-color: gray"><a href="patientappointment.php"><img src="images/add-appointment.png" alt="" style="width:200px;height:100px;background-color: gray" /></a></p>
          </li>
          <li class="last">
            <h2 style="background-color: gray;color: white">Login Panel for existing users</h2>          
            <p class="imgholder" style="background-color: gray"><a href="patientlogin.php"><img src="images/login.png" alt="" style="width:286px;height:100px;background-color: gray"  /></a></p>
          </li>
        </ul>
        <div class="clear"></div>
      </div>
    </center>
    </div>
   
    <div class="clear"></div>
  </div>
</center>
</div>
<?php
include("footer.php");
?>