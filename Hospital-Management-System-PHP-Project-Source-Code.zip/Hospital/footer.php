<div class="wrapper col5" style="background-color: gray">
  <div id="footer">

    <div id="copyright">
      <p class="fl_left">Copyright &copy; 2021 - All Rights Reserved | <a href="adminlogin.php">Admin Login Panel</a> | <a href="doctorlogin.php">Doctor Login Panel</a></p>
      <p class="fl_right"></p>
      <br class="clear" />
    </div>
    <div class="clear"></div>
  </div>
</div>
</body>
</html>